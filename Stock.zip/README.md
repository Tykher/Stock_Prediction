# Stock_Prediction
 ML app for predicting stock market value
